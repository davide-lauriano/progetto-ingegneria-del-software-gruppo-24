package com.example;

import java.util.List;
import javafx.collections.ObservableList;

/**
 * @class ContactIO
 * @brief Classe di utilità per gestire l'I/O dei contatti.
 *
 * Fornisce metodi per salvare i contatti su un file e per caricarli da un file.
 * Gestisce anche la conversione tra oggetti `Contact` e stringhe.
 */
public class ContactIO {

    /**
     * @brief Salva i contatti su un file.
     * 
     * Scrive i contatti su un file specificato, ciascuno su una riga.
     * 
     * @param filePath Percorso del file in cui salvare i contatti.
     * @param contacts Lista di contatti da salvare.
     */
    public static void saveContacts(String filePath, List<Contact> contacts) {
    }

    /**
     * @brief Carica i contatti da un file.
     * 
     * Legge i contatti da un file specificato e li aggiunge alla lista osservabile.
     * 
     * @param filePath Percorso del file da cui caricare i contatti.
     * @param contacts Lista osservabile in cui aggiungere i contatti caricati.
     */
    public static void loadContacts(String filePath, ObservableList<Contact> contacts) {
    }

    /**
     * @brief Converte un oggetto `Contact` in una stringa salvabile su file.
     * 
     * Genera una stringa rappresentativa di un oggetto `Contact` in un formato
     * compatibile con il salvataggio su file (ad esempio CSV).
     * 
     * @param contact Contatto da convertire.
     * @return Stringa rappresentante il contatto, pronta per essere salvata su file.
     */
    private static String contactToLine(Contact contact) {
    }

    /**
     * @brief Converte una stringa in un oggetto `Contact`.
     * 
     * Interpreta una stringa letta da un file e la trasforma in un oggetto `Contact`.
     * La stringa deve essere in un formato valido.
     * 
     * @param line Stringa che rappresenta un contatto (estratta da un file).
     * @return Oggetto `Contact` corrispondente alla stringa, o `null` se la stringa non è valida.
     */
    private static Contact lineToContact(String line) {
    }

    /**
     * @brief Mostra un messaggio di errore.
     * 
     * Stampa un messaggio di errore nel log della console.
     * 
     * @param message Messaggio di errore da mostrare.
     */
    private static void showError(String message) {
    }
}
