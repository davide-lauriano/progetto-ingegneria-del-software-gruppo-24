package com.example;

import java.util.List;
import javafx.beans.property.StringProperty;

/**
 * @class Contact
 * @brief Rappresenta un contatto della rubrica con informazioni di base.
 *
 * Un contatto include il nome, cognome, una lista di numeri di telefono,
 * una lista di indirizzi email e uno stato (es. Preferito o Emergenza).
 */
public class Contact {

    private final StringProperty firstName;
    private final StringProperty lastName;
    private final List<String> telefoni;
    private final List<String> email;
    private final StringProperty status;

    /**
     * @brief Costruttore della classe Contact.
     * 
     * @param firstName Nome del contatto.
     * @param lastName Cognome del contatto.
     * @param telefoni Lista dei numeri di telefono.
     * @param email Lista degli indirizzi email.
     * @param status Stato del contatto (es. "Preferito", "Emergenza").
     */
    public Contact(String firstName, String lastName, List<String> telefoni, List<String> email, String status) {
    }

    /**
     * @brief Ottiene il nome del contatto.
     * @return Nome del contatto.
     */
    public String getFirstName() {
    }

    /**
     * @brief Imposta il nome del contatto.
     * @param firstName Nome da impostare.
     */
    public void setFirstName(String firstName) {
    }

    /**
     * @brief Ottiene la proprietà del nome per il binding in JavaFX.
     * @return Proprietà del nome.
     */
    public StringProperty firstNameProperty() {
    }

    // Ripeti la stessa struttura di commenti per gli altri getter, setter e metodi.
    /**
     * @brief Ottiene la lista dei numeri di telefono del contatto.
     * @return Lista dei numeri di telefono.
     */
    public List<String> getTelefoni() {
    }

    /**
     * @brief Imposta la lista dei numeri di telefono del contatto.
     * @param telefoni Lista di numeri di telefono da impostare.
     */
    public void setTelefoni(List<String> telefoni) {
    }

    /**
     * @brief Ottiene lo stato del contatto.
     * @return Stato del contatto.
     */
    public String getStatus() {
    }

    /**
     * @brief Imposta lo stato del contatto.
     * @param status Stato da impostare.
     */
    public void setStatus(String status) {
    }

    /**
     * @brief Converte i dettagli del contatto in una stringa leggibile.
     * @return Stringa rappresentativa del contatto.
     */
    public String toString() {
    }
}
