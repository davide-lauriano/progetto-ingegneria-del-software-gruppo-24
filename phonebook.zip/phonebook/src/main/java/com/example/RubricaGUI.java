package com.example;

import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

/**
 * @class RubricaGUI
 * @brief Gestisce l'interfaccia grafica della rubrica telefonica.
 */
public class RubricaGUI {

    private TableView<Contact> table;
    private ObservableList<Contact> contacts;
    private FilteredList<Contact> filteredContacts;
    private static final String FILE_PATH;

    /**
     * @brief Punto di ingresso dell'applicazione.
     * @param args Argomenti della riga di comando.
     */
    public static void main(String[] args) {
    }

    /**
     * @brief Avvia l'interfaccia grafica.
     * @param primaryStage Stage principale dell'applicazione.
     */
    public void start(Stage primaryStage) {
    }

    /**
     * @brief Apre una finestra per aggiungere o modificare un contatto.
     * @param contact Contatto da modificare, o null per aggiungerne uno nuovo.
     */
    private void openAddEditContactWindow(Contact contact) {
    }

    /**
     * @brief Mostra i dettagli di un contatto.
     * @param contact Contatto di cui mostrare i dettagli.
     */
    private void showContactDetails(Contact contact) {
    }

    /**
     * @brief Elimina il contatto selezionato dalla rubrica.
     */
    private void deleteContact() {
    }

    /**
     * @brief Mostra le opzioni di ordinamento per i contatti.
     */
    private void showSortOptions() {
    }

    /**
     * @brief Salva i contatti su file.
     */
    private void saveContacts() {
    }

    /**
     * @brief Mostra un messaggio di errore.
     * @param message Messaggio di errore da visualizzare.
     */
    private void showErrorDialog(String message) {
    }
}
