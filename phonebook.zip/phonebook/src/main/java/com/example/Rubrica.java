package com.example;

import java.util.List;

/**
 * @class Rubrica
 * @brief Classe che gestisce la lista dei contatti della rubrica.
 *
 * Consente di aggiungere, modificare, eliminare e cercare contatti,
 * oltre a salvare e caricare la rubrica da file.
 */
public class Rubrica {

    private final List<Contact> contatti;

    /**
     * @brief Costruttore della classe Rubrica.
     * Inizializza una nuova lista di contatti.
     */
    public Rubrica() {
    }

    /**
     * @brief Aggiunge un contatto alla rubrica.
     * @param contatto Contatto da aggiungere.
     */
    public void aggiungiContatto(Contact contatto) {
    }

    /**
     * @brief Modifica un contatto nella rubrica.
     * @param id Identificatore del contatto da modificare.
     * @param nuovoContatto Nuovi dati del contatto.
     */
    public void modificaContatto(int id, Contact nuovoContatto) {
    }

    /**
     * @brief Elimina un contatto dalla rubrica.
     * @param id Identificatore del contatto da eliminare.
     */
    public void eliminaContatto(int id) {
    }

    /**
     * @brief Cerca contatti in base a una parola chiave (nome o cognome).
     * @param parolaChiave Parola chiave per la ricerca.
     * @return Lista di contatti che corrispondono alla parola chiave.
     */
    public List<Contact> cercaContatti(String parolaChiave) {
    }

    /**
     * @brief Salva i contatti su un file.
     * @param filePath Percorso del file di destinazione.
     */
    public void salvaSuFile(String filePath) {
    }

    /**
     * @brief Carica i contatti da un file.
     * @param filePath Percorso del file sorgente.
     */
    public void caricaDaFile(String filePath) {
    }

    /**
     * @brief Ottiene la lista di contatti.
     * @return Lista dei contatti.
     */
    public List<Contact> getContatti() {
    }
}
