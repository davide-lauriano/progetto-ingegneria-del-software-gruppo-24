package com.example;

import java.util.List;

/**
 * @class RubricaController
 * @brief Classe di controllo per la gestione della rubrica.
 *
 * Gestisce l'interazione tra l'interfaccia utente e la classe Rubrica.
 */
public class RubricaController {

    private final Rubrica rubrica;

    /**
     * @brief Costruttore del controller.
     * Inizializza una nuova rubrica.
     */
    public RubricaController() {
    }

    /**
     * @brief Aggiunge un nuovo contatto alla rubrica.
     * @param contatto Contatto da aggiungere.
     */
    public void aggiungiContatto(Contact contatto) {
    }

    /**
     * @brief Modifica un contatto esistente nella rubrica.
     * @param id Identificatore del contatto da modificare.
     * @param nuovoContatto Nuovi dati del contatto.
     */
    public void modificaContatto(int id, Contact nuovoContatto) {
    }

    /**
     * @brief Elimina un contatto dalla rubrica.
     * @param id Identificatore del contatto da eliminare.
     */
    public void eliminaContatto(int id) {
    }

    /**
     * @brief Cerca contatti in base a una parola chiave.
     * @param parolaChiave Parola chiave per la ricerca.
     * @return Lista di contatti corrispondenti.
     */
    public List<Contact> cercaContatti(String parolaChiave) {
    }

    /**
     * @brief Ottiene la lista completa dei contatti.
     * @return Lista dei contatti.
     */
    public List<Contact> getContatti() {
    }

    /**
     * @brief Salva i contatti su un file.
     * @param filePath Percorso del file di destinazione.
     */
    public void salva(String filePath) {
    }

    /**
     * @brief Carica i contatti da un file.
     * @param filePath Percorso del file sorgente.
     */
    public void carica(String filePath) {
    }
}
